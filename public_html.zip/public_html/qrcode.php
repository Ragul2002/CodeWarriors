 <?php
        if (isset($_GET['orderid'])) {
          $input_order_id = $_GET['orderid'];
          //echo $input_order_id;
        }

        $query = "SELECT * FROM orders WHERE order_id=$input_order_id";

        $select_order = mysqli_query($connection,$query);

        while ($row = mysqli_fetch_assoc($select_order)) {
            $passenger = $row['user_name'];
            $passenger_age = $row['user_age'];
            $source = $row['source'];
            $destination = $row['destination'];
            $dob = $row['date'];
            $cost = $row['cost'];
            $orderid = $row['order_id'];
            $travel_bus_id = $row['bus_id'];

            ?>

            <h2>Passenger Details:-</h2>

            <table class="table table-striped" style="width: 100%">
              <tbody>
                <tr>
                  <td><b>Passenger Name:</b> </td>
                  <td><?php echo $passenger; ?></td>
                </tr>
                <tr>
                  <td><b>Passenger Age:</b> </td>
                  <td><?php echo $passenger_age; ?></td>
                </tr>
                <tr>
                  <td><b>Source: </b></td>
                  <td><?php echo ucfirst($source); ?></td>
                </tr>
                <tr>
                  <td><b>Destination: </b></td>
                  <td><?php echo ucfirst($destination); ?></td>
                </tr>
                <tr>
                  <td><b>Date Of Booking: </b></td>
                  <td><?php echo $dob; ?></td>
                </tr>
                <tr>
                  <td><b>Cost: </b></td>
                  <td><?php echo $cost; ?></td>
                </tr>
                <br>
              </tbody>
            </table>

          <?php } ?>

<?php

$connection = mysqli_connect("localhost",'id18307753_safesafari','qwzw3=iTjy)/dG}V','id18307753_bus');

if(!$connection) {
	die("Unable to connect" . mysqli_error($connection));
}

?>